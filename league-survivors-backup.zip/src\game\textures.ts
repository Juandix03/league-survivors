import * as Phaser from 'phaser'
import { TEXTURE } from './constants'

function bake(scene: Phaser.Scene, key: string, width: number, height: number, draw: (g: Phaser.GameObjects.Graphics) => void) {
  if (scene.textures.exists(key)) {
    return
  }

  const graphics = scene.add.graphics()
  draw(graphics)
  graphics.generateTexture(key, width, height)
  graphics.destroy()
}

export function bakeArenaTextures(scene: Phaser.Scene) {
  bake(scene, TEXTURE.grass, 96, 96, (g) => {
    g.fillStyle(0x3d7a32, 1)
    g.fillRect(0, 0, 96, 96)
    g.fillStyle(0x4a8f3c, 1)
    g.fillRect(8, 12, 28, 22)
    g.fillRect(52, 48, 34, 26)
    g.fillStyle(0x2f6a28, 1)
    g.fillRect(40, 6, 22, 18)
    g.fillRect(10, 58, 30, 24)
    g.fillStyle(0x5aa344, 0.85)
    g.fillCircle(18, 30, 4)
    g.fillCircle(70, 20, 3)
    g.fillCircle(44, 72, 5)
    g.fillCircle(82, 78, 3)
    g.fillStyle(0x2b5724, 0.7)
    g.fillCircle(58, 38, 3)
    g.fillCircle(26, 80, 2)
  })

  bake(scene, TEXTURE.mage, 64, 64, (g) => {
    g.fillStyle(0x140c1f, 0.35)
    g.fillEllipse(32, 54, 30, 10)

    g.fillStyle(0x2a1458, 1)
    g.fillEllipse(32, 40, 32, 34)
    g.fillStyle(0x6d28d9, 1)
    g.fillEllipse(32, 38, 24, 28)
    g.lineStyle(2, 0xfbbf24, 0.95)
    g.strokeEllipse(32, 38, 24, 28)

    g.fillStyle(0x1e0b3b, 1)
    g.fillCircle(32, 22, 13)
    g.fillStyle(0x7c3aed, 1)
    g.fillCircle(32, 20, 10)
    g.fillStyle(0xf3c6b4, 1)
    g.fillCircle(32, 24, 7)

    g.fillStyle(0x1e1b4b, 1)
    g.fillCircle(29, 24, 1.5)
    g.fillCircle(35, 24, 1.5)

    g.fillStyle(0x22d3ee, 1)
    g.fillCircle(32, 38, 3.2)
    g.fillStyle(0xecfeff, 1)
    g.fillCircle(32, 38, 1.4)

    g.lineStyle(3, 0xc4a574, 1)
    g.lineBetween(47, 54, 52, 14)
    g.fillStyle(0xa78bfa, 1)
    g.fillCircle(52, 12, 5.5)
    g.lineStyle(1.5, 0xf5d0ff, 0.9)
    g.strokeCircle(52, 12, 7)
    g.fillStyle(0xfaf5ff, 1)
    g.fillCircle(52, 12, 2.2)
  })

  bake(scene, TEXTURE.bush, 48, 40, (g) => {
    g.fillStyle(0x163016, 0.35)
    g.fillEllipse(24, 34, 30, 8)
    g.fillStyle(0x1f5a28, 1)
    g.fillCircle(16, 22, 12)
    g.fillCircle(30, 20, 13)
    g.fillCircle(24, 14, 11)
    g.fillStyle(0x2f7a36, 1)
    g.fillCircle(20, 18, 7)
    g.fillCircle(28, 16, 6)
  })

  bake(scene, TEXTURE.rock, 36, 28, (g) => {
    g.fillStyle(0x1a1a1a, 0.3)
    g.fillEllipse(18, 24, 24, 8)
    g.fillStyle(0x6b7280, 1)
    g.fillEllipse(18, 16, 26, 16)
    g.fillStyle(0x9ca3af, 1)
    g.fillEllipse(14, 13, 10, 6)
    g.fillStyle(0x4b5563, 1)
    g.fillEllipse(24, 18, 8, 5)
  })

  bake(scene, TEXTURE.flower, 20, 20, (g) => {
    g.fillStyle(0x3f7a2c, 1)
    g.fillRect(9, 10, 2, 8)
    g.fillStyle(0xc4b5fd, 1)
    g.fillCircle(7, 8, 3)
    g.fillCircle(13, 8, 3)
    g.fillCircle(10, 5, 3)
    g.fillCircle(10, 11, 3)
    g.fillStyle(0xfde68a, 1)
    g.fillCircle(10, 8, 2)
  })

  bake(scene, TEXTURE.rune, 120, 120, (g) => {
    g.lineStyle(4, 0x7c3aed, 0.55)
    g.strokeCircle(60, 60, 48)
    g.lineStyle(2, 0xfbbf24, 0.4)
    g.strokeCircle(60, 60, 34)
    g.lineStyle(1.5, 0xa78bfa, 0.7)
    g.strokeCircle(60, 60, 18)
    g.fillStyle(0xc4b5fd, 0.45)
    g.fillCircle(60, 12, 3)
    g.fillCircle(60, 108, 3)
    g.fillCircle(12, 60, 3)
    g.fillCircle(108, 60, 3)
  })
}
