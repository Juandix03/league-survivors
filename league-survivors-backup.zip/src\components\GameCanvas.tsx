import { useEffect, useRef, useState } from 'react'
import { createGame } from '../game/createGame'
import { formatElapsed, INITIAL_HUD } from '../game/hud'
import type { HudSnapshot } from '../game/hud'

export function GameCanvas() {
  const parentRef = useRef<HTMLDivElement>(null)
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD)

  useEffect(() => {
    const parent = parentRef.current
    if (!parent) {
      return
    }

    let game: ReturnType<typeof createGame> | undefined
    const timeoutId = window.setTimeout(() => {
      game = createGame(parent, setHud)
    }, 0)

    return () => {
      window.clearTimeout(timeoutId)
      game?.destroy(true)
    }
  }, [])

  const healthPercent = Math.max(0, Math.min(100, (hud.health / hud.maxHealth) * 100))

  return (
    <div className="app-shell">
      <header className="top-bar">
        <p className="kicker">Bullet heaven · prototipo</p>
        <h1>LEAGUE SURVIVORS</h1>
      </header>

      <div className="stage">
        <div ref={parentRef} className="game-parent" />

        <div className="hud" aria-live="polite">
          <div className="hud-panel health-panel">
            <div className="hud-label-row">
              <span>Vitalidad</span>
              <span>
                {hud.health}/{hud.maxHealth}
              </span>
            </div>
            <div className="health-track">
              <div className="health-fill" style={{ width: `${healthPercent}%` }} />
            </div>
          </div>

          <div className="hud-panel timer-panel">
            <span className="hud-label">Tiempo</span>
            <strong>{formatElapsed(hud.elapsedMs)}</strong>
          </div>

          <p className="controls-hint">Moverse · WASD o flechas</p>
        </div>
      </div>
    </div>
  )
}
