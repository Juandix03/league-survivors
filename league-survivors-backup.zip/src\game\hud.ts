export type HudSnapshot = {
  health: number
  maxHealth: number
  elapsedMs: number
}

export const INITIAL_HUD: HudSnapshot = {
  health: 100,
  maxHealth: 100,
  elapsedMs: 0,
}

export type HudListener = (snapshot: HudSnapshot) => void

export function formatElapsed(elapsedMs: number): string {
  const totalSeconds = Math.max(0, Math.floor(elapsedMs / 1000))
  const minutes = Math.floor(totalSeconds / 60)
  const seconds = totalSeconds % 60
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
}
