export const WORLD_WIDTH = 2560
export const WORLD_HEIGHT = 2560

export const PLAYER_SPEED = 240
export const PLAYER_RADIUS = 22
export const PLAYER_MAX_HEALTH = 100

export const TEXTURE = {
  grass: 'grass',
  mage: 'mage',
  bush: 'bush',
  rock: 'rock',
  flower: 'flower',
  rune: 'rune',
} as const
