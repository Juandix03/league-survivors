import * as Phaser from 'phaser'
import type { HudListener } from './hud'
import { ArenaScene } from './scenes/ArenaScene'

export function createGame(parent: HTMLElement, onHud: HudListener): Phaser.Game {
  parent.replaceChildren()

  return new Phaser.Game({
    type: Phaser.AUTO,
    parent,
    backgroundColor: '#14301a',
    banner: false,
    audio: {
      noAudio: true,
    },
    scale: {
      mode: Phaser.Scale.RESIZE,
      autoCenter: Phaser.Scale.CENTER_BOTH,
      width: '100%',
      height: '100%',
    },
    physics: {
      default: 'arcade',
      arcade: {
        gravity: { x: 0, y: 0 },
        debug: false,
      },
    },
    callbacks: {
      preBoot: (game) => {
        game.registry.set('onHud', onHud)
      },
    },
    scene: [ArenaScene],
  })
}
