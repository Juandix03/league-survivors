import * as Phaser from 'phaser'
import {
  PLAYER_MAX_HEALTH,
  PLAYER_RADIUS,
  PLAYER_SPEED,
  TEXTURE,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from '../constants'
import type { HudListener } from '../hud'
import { bakeArenaTextures } from '../textures'

type MoveKeys = {
  up: Phaser.Input.Keyboard.Key
  down: Phaser.Input.Keyboard.Key
  left: Phaser.Input.Keyboard.Key
  right: Phaser.Input.Keyboard.Key
}

function mulberry32(seed: number) {
  let a = seed >>> 0
  return () => {
    a += 0x6d2b79f5
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export class ArenaScene extends Phaser.Scene {
  private player: Phaser.Physics.Arcade.Sprite | undefined
  private cursors: Phaser.Types.Input.Keyboard.CursorKeys | undefined
  private wasd: MoveKeys | undefined
  private onHud: HudListener | undefined
  private startedAt = 0
  private lastHudEmit = 0
  private health = PLAYER_MAX_HEALTH

  constructor() {
    super({ key: 'ArenaScene' })
  }

  create() {
    this.onHud = this.registry.get('onHud') as HudListener | undefined
    this.health = PLAYER_MAX_HEALTH
    this.startedAt = this.time.now
    this.lastHudEmit = 0

    bakeArenaTextures(this)

    this.physics.world.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT)

    this.add
      .tileSprite(0, 0, WORLD_WIDTH, WORLD_HEIGHT, TEXTURE.grass)
      .setOrigin(0)
      .setDepth(0)

    const plaza = this.add.circle(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 160, 0x5b8f3c, 0.55)
    plaza.setDepth(1)

    this.add.image(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, TEXTURE.rune).setDepth(2)

    this.scatterDecor()
    this.drawWorldBorder()

    const player = this.physics.add.sprite(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, TEXTURE.mage)
    player.setCircle(PLAYER_RADIUS, 32 - PLAYER_RADIUS, 32 - PLAYER_RADIUS)
    player.setCollideWorldBounds(true)
    player.setDepth(player.y)
    this.player = player

    this.cameras.main.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT)
    this.cameras.main.startFollow(player, true, 0.12, 0.12)
    this.cameras.main.setZoom(1)
    this.cameras.main.fadeIn(450, 12, 8, 20)

    const keyboard = this.input.keyboard
    if (keyboard) {
      this.cursors = keyboard.createCursorKeys()
      this.wasd = keyboard.addKeys({
        up: 'W',
        down: 'S',
        left: 'A',
        right: 'D',
      }) as MoveKeys
    }

    this.emitHud(this.time.now)
  }

  update(time: number) {
    const player = this.player
    if (!player?.body) {
      return
    }

    const velocity = this.readMoveVector()
    player.setVelocity(velocity.x, velocity.y)

    if (velocity.x !== 0 || velocity.y !== 0) {
      player.setRotation(Math.atan2(velocity.y, velocity.x) + Math.PI / 2)
    }

    player.setDepth(player.y)

    if (time - this.lastHudEmit >= 100) {
      this.emitHud(time)
    }
  }

  private readMoveVector() {
    let x = 0
    let y = 0

    const left = Boolean(this.cursors?.left.isDown || this.wasd?.left.isDown)
    const right = Boolean(this.cursors?.right.isDown || this.wasd?.right.isDown)
    const up = Boolean(this.cursors?.up.isDown || this.wasd?.up.isDown)
    const down = Boolean(this.cursors?.down.isDown || this.wasd?.down.isDown)

    if (left) x -= 1
    if (right) x += 1
    if (up) y -= 1
    if (down) y += 1

    if (x === 0 && y === 0) {
      return { x: 0, y: 0 }
    }

    const length = Math.hypot(x, y)
    return {
      x: (x / length) * PLAYER_SPEED,
      y: (y / length) * PLAYER_SPEED,
    }
  }

  private emitHud(time: number) {
    this.lastHudEmit = time
    this.onHud?.({
      health: this.health,
      maxHealth: PLAYER_MAX_HEALTH,
      elapsedMs: Math.max(0, time - this.startedAt),
    })
  }

  private scatterDecor() {
    const random = mulberry32(13)
    const centerX = WORLD_WIDTH / 2
    const centerY = WORLD_HEIGHT / 2

    for (let i = 0; i < 70; i += 1) {
      const x = 80 + random() * (WORLD_WIDTH - 160)
      const y = 80 + random() * (WORLD_HEIGHT - 160)
      if (Phaser.Math.Distance.Between(x, y, centerX, centerY) < 200) {
        continue
      }
      this.add.image(x, y, TEXTURE.bush).setDepth(y).setScale(0.85 + random() * 0.4)
    }

    for (let i = 0; i < 36; i += 1) {
      const x = 80 + random() * (WORLD_WIDTH - 160)
      const y = 80 + random() * (WORLD_HEIGHT - 160)
      this.add.image(x, y, TEXTURE.rock).setDepth(y).setScale(0.8 + random() * 0.5)
    }

    for (let i = 0; i < 50; i += 1) {
      const x = 80 + random() * (WORLD_WIDTH - 160)
      const y = 80 + random() * (WORLD_HEIGHT - 160)
      this.add.image(x, y, TEXTURE.flower).setDepth(y).setScale(0.8 + random() * 0.5)
    }
  }

  private drawWorldBorder() {
    const border = this.add.graphics()
    border.lineStyle(18, 0x1a1028, 0.9)
    border.strokeRect(8, 8, WORLD_WIDTH - 16, WORLD_HEIGHT - 16)
    border.lineStyle(4, 0x6d28d9, 0.45)
    border.strokeRect(22, 22, WORLD_WIDTH - 44, WORLD_HEIGHT - 44)
    border.setDepth(3)
  }
}
