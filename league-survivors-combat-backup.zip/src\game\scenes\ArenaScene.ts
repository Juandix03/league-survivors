import * as Phaser from 'phaser'
import {
  PLAYER_MAX_HEALTH,
  PLAYER_RADIUS,
  PLAYER_SPEED,
  TEXTURE,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from '../constants'
import type { HudListener } from '../hud'
import { bakeArenaTextures } from '../textures'

type MoveKeys = {
  up: Phaser.Input.Keyboard.Key
  down: Phaser.Input.Keyboard.Key
  left: Phaser.Input.Keyboard.Key
  right: Phaser.Input.Keyboard.Key
}

type Enemy = {
  visual: Phaser.GameObjects.Container
  health: number
  speed: number
  radius: number
}

type Projectile = {
  visual: Phaser.GameObjects.Arc
  vx: number
  vy: number
  remainingMs: number
}

function mulberry32(seed: number) {
  let a = seed >>> 0
  return () => {
    a += 0x6d2b79f5
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export class ArenaScene extends Phaser.Scene {
  private player: Phaser.Physics.Arcade.Sprite | undefined
  private cursors: Phaser.Types.Input.Keyboard.CursorKeys | undefined
  private wasd: MoveKeys | undefined
  private onHud: HudListener | undefined

  private startedAt = 0
  private lastHudEmit = 0
  private health = PLAYER_MAX_HEALTH
  private kills = 0
  private gameOver = false

  private enemies: Enemy[] = []
  private projectiles: Projectile[] = []
  private nextSpawnAt = 0
  private nextShotAt = 0
  private invulnerableUntil = 0

  constructor() {
    super({ key: 'ArenaScene' })
  }

  create() {
    this.onHud = this.registry.get('onHud') as HudListener | undefined
    this.health = PLAYER_MAX_HEALTH
    this.kills = 0
    this.gameOver = false
    this.startedAt = this.time.now
    this.lastHudEmit = 0
    this.nextSpawnAt = this.time.now + 900
    this.nextShotAt = this.time.now + 500
    this.invulnerableUntil = 0
    this.enemies = []
    this.projectiles = []

    bakeArenaTextures(this)

    this.physics.world.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT)

    this.add
      .tileSprite(0, 0, WORLD_WIDTH, WORLD_HEIGHT, TEXTURE.grass)
      .setOrigin(0)
      .setDepth(0)

    this.add
      .circle(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 160, 0x5b8f3c, 0.55)
      .setDepth(1)

    this.add
      .image(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, TEXTURE.rune)
      .setDepth(2)

    this.scatterDecor()
    this.drawWorldBorder()

    const player = this.physics.add.sprite(
      WORLD_WIDTH / 2,
      WORLD_HEIGHT / 2,
      TEXTURE.mage,
    )

    player.setCircle(
      PLAYER_RADIUS,
      32 - PLAYER_RADIUS,
      32 - PLAYER_RADIUS,
    )
    player.setCollideWorldBounds(true)
    player.setDepth(player.y)
    this.player = player

    this.cameras.main.setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT)
    this.cameras.main.startFollow(player, true, 0.12, 0.12)
    this.cameras.main.setZoom(1)
    this.cameras.main.fadeIn(450, 12, 8, 20)

    const keyboard = this.input.keyboard
    if (keyboard) {
      this.cursors = keyboard.createCursorKeys()
      this.wasd = keyboard.addKeys({
        up: 'W',
        down: 'S',
        left: 'A',
        right: 'D',
      }) as MoveKeys
    }

    this.emitHud(this.time.now)
  }

  update(time: number, delta: number) {
    const player = this.player

    if (!player?.body) {
      return
    }

    if (!this.gameOver) {
      const velocity = this.readMoveVector()
      player.setVelocity(velocity.x, velocity.y)

      if (velocity.x !== 0 || velocity.y !== 0) {
        player.setRotation(
          Math.atan2(velocity.y, velocity.x) + Math.PI / 2,
        )
      }

      if (time < this.invulnerableUntil) {
        player.setAlpha(Math.floor(time / 90) % 2 === 0 ? 0.45 : 1)
      } else {
        player.setAlpha(1)
      }

      player.setDepth(player.y)

      this.updateEnemies(time, delta)
      this.spawnEnemies(time)
      this.autoAttack(time)
      this.updateProjectiles(delta)
    } else {
      player.setVelocity(0, 0)
    }

    if (time - this.lastHudEmit >= 100) {
      this.emitHud(time)
    }
  }

  private updateEnemies(time: number, delta: number) {
    const player = this.player
    if (!player) return

    const step = delta / 1000

    for (const enemy of this.enemies) {
      const dx = player.x - enemy.visual.x
      const dy = player.y - enemy.visual.y
      const distance = Math.hypot(dx, dy)

      if (distance > 0) {
        enemy.visual.x += (dx / distance) * enemy.speed * step
        enemy.visual.y += (dy / distance) * enemy.speed * step
        enemy.visual.setDepth(enemy.visual.y)
      }

      if (
        distance < PLAYER_RADIUS + enemy.radius &&
        time >= this.invulnerableUntil
      ) {
        this.health = Math.max(0, this.health - 10)
        this.invulnerableUntil = time + 800

        if (this.health <= 0) {
          this.gameOver = true
          player.setVelocity(0, 0)
        }

        this.emitHud(time)
      }
    }
  }

  private spawnEnemies(time: number) {
    if (time < this.nextSpawnAt || this.enemies.length >= 30) {
      return
    }

    this.nextSpawnAt = time + 1200

    const player = this.player
    if (!player) return

    const angle = Math.random() * Math.PI * 2
    const distance = 440 + Math.random() * 160
    const x = Phaser.Math.Clamp(
      player.x + Math.cos(angle) * distance,
      40,
      WORLD_WIDTH - 40,
    )
    const y = Phaser.Math.Clamp(
      player.y + Math.sin(angle) * distance,
      40,
      WORLD_HEIGHT - 40,
    )

    const shadow = this.add.ellipse(0, 11, 35, 14, 0x160c20, 0.4)
    const body = this.add.circle(0, 0, 15, 0x991b1b, 1)
    body.setStrokeStyle(3, 0xfca5a5, 1)

    const leftEye = this.add.circle(-5, -3, 3, 0xfff7ed, 1)
    const rightEye = this.add.circle(5, -3, 3, 0xfff7ed, 1)

    const visual = this.add.container(x, y, [
      shadow,
      body,
      leftEye,
      rightEye,
    ])
    visual.setDepth(y)

    this.enemies.push({
      visual,
      health: 2,
      speed: 65 + Math.random() * 25,
      radius: 15,
    })
  }

  private autoAttack(time: number) {
    if (time < this.nextShotAt || this.enemies.length === 0) {
      return
    }

    const player = this.player
    if (!player) return

    let target = this.enemies[0]
    let closestDistance = Number.POSITIVE_INFINITY

    for (const enemy of this.enemies) {
      const distance = Phaser.Math.Distance.Between(
        player.x,
        player.y,
        enemy.visual.x,
        enemy.visual.y,
      )

      if (distance < closestDistance) {
        closestDistance = distance
        target = enemy
      }
    }

    const dx = target.visual.x - player.x
    const dy = target.visual.y - player.y
    const length = Math.hypot(dx, dy) || 1
    const speed = 520

    const visual = this.add.circle(
      player.x,
      player.y,
      7,
      0xa78bfa,
      1,
    )
    visual.setStrokeStyle(2, 0xf5d0fe, 1)
    visual.setDepth(player.y + 2)

    this.projectiles.push({
      visual,
      vx: (dx / length) * speed,
      vy: (dy / length) * speed,
      remainingMs: 1600,
    })

    this.nextShotAt = time + 450
  }

  private updateProjectiles(delta: number) {
    const step = delta / 1000

    for (let i = this.projectiles.length - 1; i >= 0; i -= 1) {
      const projectile = this.projectiles[i]

      projectile.visual.x += projectile.vx * step
      projectile.visual.y += projectile.vy * step
      projectile.visual.setDepth(projectile.visual.y)
      projectile.remainingMs -= delta

      let hitIndex = -1

      for (let j = 0; j < this.enemies.length; j += 1) {
        const enemy = this.enemies[j]
        const distance = Phaser.Math.Distance.Between(
          projectile.visual.x,
          projectile.visual.y,
          enemy.visual.x,
          enemy.visual.y,
        )

        if (distance < enemy.radius + 7) {
          hitIndex = j
          break
        }
      }

      if (hitIndex !== -1) {
        const enemy = this.enemies[hitIndex]
        enemy.health -= 1
        projectile.visual.destroy()
        this.projectiles.splice(i, 1)

        if (enemy.health <= 0) {
          enemy.visual.destroy()
          this.enemies.splice(hitIndex, 1)
          this.kills += 1
          this.emitHud(this.time.now)
        }

        continue
      }

      if (
        projectile.remainingMs <= 0 ||
        projectile.visual.x < 0 ||
        projectile.visual.x > WORLD_WIDTH ||
        projectile.visual.y < 0 ||
        projectile.visual.y > WORLD_HEIGHT
      ) {
        projectile.visual.destroy()
        this.projectiles.splice(i, 1)
      }
    }
  }

  private readMoveVector() {
    let x = 0
    let y = 0

    const left = Boolean(this.cursors?.left.isDown || this.wasd?.left.isDown)
    const right = Boolean(this.cursors?.right.isDown || this.wasd?.right.isDown)
    const up = Boolean(this.cursors?.up.isDown || this.wasd?.up.isDown)
    const down = Boolean(this.cursors?.down.isDown || this.wasd?.down.isDown)

    if (left) x -= 1
    if (right) x += 1
    if (up) y -= 1
    if (down) y += 1

    if (x === 0 && y === 0) {
      return { x: 0, y: 0 }
    }

    const length = Math.hypot(x, y)

    return {
      x: (x / length) * PLAYER_SPEED,
      y: (y / length) * PLAYER_SPEED,
    }
  }

  private emitHud(time: number) {
    this.lastHudEmit = time
    this.onHud?.({
      health: this.health,
      maxHealth: PLAYER_MAX_HEALTH,
      elapsedMs: Math.max(0, time - this.startedAt),
      kills: this.kills,
      gameOver: this.gameOver,
    })
  }

  private scatterDecor() {
    const random = mulberry32(13)
    const centerX = WORLD_WIDTH / 2
    const centerY = WORLD_HEIGHT / 2

    for (let i = 0; i < 70; i += 1) {
      const x = 80 + random() * (WORLD_WIDTH - 160)
      const y = 80 + random() * (WORLD_HEIGHT - 160)

      if (Phaser.Math.Distance.Between(x, y, centerX, centerY) < 200) {
        continue
      }

      this.add
        .image(x, y, TEXTURE.bush)
        .setDepth(y)
        .setScale(0.85 + random() * 0.4)
    }

    for (let i = 0; i < 36; i += 1) {
      const x = 80 + random() * (WORLD_WIDTH - 160)
      const y = 80 + random() * (WORLD_HEIGHT - 160)

      this.add
        .image(x, y, TEXTURE.rock)
        .setDepth(y)
        .setScale(0.8 + random() * 0.5)
    }

    for (let i = 0; i < 50; i += 1) {
      const x = 80 + random() * (WORLD_WIDTH - 160)
      const y = 80 + random() * (WORLD_HEIGHT - 160)

      this.add
        .image(x, y, TEXTURE.flower)
        .setDepth(y)
        .setScale(0.8 + random() * 0.5)
    }
  }

  private drawWorldBorder() {
    const border = this.add.graphics()
    border.lineStyle(18, 0x1a1028, 0.9)
    border.strokeRect(8, 8, WORLD_WIDTH - 16, WORLD_HEIGHT - 16)
    border.lineStyle(4, 0x6d28d9, 0.45)
    border.strokeRect(22, 22, WORLD_WIDTH - 44, WORLD_HEIGHT - 44)
    border.setDepth(3)
  }
}